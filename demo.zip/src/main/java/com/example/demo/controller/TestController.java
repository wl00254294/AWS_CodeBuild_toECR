package com.example.demo.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class TestController {

	@RequestMapping(value="/test3", method = RequestMethod.GET)
	 public String test3(HttpServletRequest request, Model model, HttpSession session
             ,HttpServletResponse response) throws IOException
	 {
		return "Code Build";
	 }
	
	 @RequestMapping(value="/test", method = RequestMethod.GET)
     public String test(HttpServletRequest request, Model model, HttpSession session
                     ,HttpServletResponse response) throws IOException
     {
		 	String cookieval="";
   		 	 Cookie[] cookies = request.getCookies();
             if(cookies != null) {
         	    for(Cookie cookie : cookies) {
         	        if("AWSALB".equals(cookie.getName()))
         	        {
         	        	cookieval = cookie.getValue();
         	        }
         	      
         	    }
             }
		 	
         
           
             
             Cookie rescookie = new Cookie("AWSALB", cookieval);
             Cookie rescookie2 = new Cookie("AWSALB2", cookieval);
             response.addCookie(rescookie2);
             response.addCookie(rescookie);
             response.sendRedirect("test2");
             return "ECS Second==> "+cookieval;

     }

	 @RequestMapping(value="/test2", method = RequestMethod.GET)
     public String test2(HttpServletRequest request, Model model, HttpSession session
                     ) throws UnsupportedEncodingException
     {

		 String cookieval="";
		 String cookieval2="";
		 Cookie[] cookies = request.getCookies();
         if(cookies != null) {
     	    for(Cookie cookie : cookies) {
     	        if("AWSALB".equals(cookie.getName()))
     	        {
     	        	cookieval = cookie.getValue();
     	        }
     	        if("AWSALB2".equals(cookie.getName()))
     	        {
     	        	cookieval2 = cookie.getValue();
     	        }
     	    }
         }
             //String out=(String) session.getAttribute("myattr");
             return "Keep session Second==> "+cookieval+","+cookieval2;

     }
}